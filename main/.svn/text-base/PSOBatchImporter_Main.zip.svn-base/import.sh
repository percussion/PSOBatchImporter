#/bin/sh
#set -x
   export RXIMPORT_HOME=/home/rhythmyx/PSOBatchImporter
   export RHYTHMYX_HOME=/home/rhythmyx/Rhythmyx
   export JAVA_HOME=$RHYTHMYX_HOME/JRE/
   export ANT_HOME=$RHYTHMYX_HOME/Patch/InstallToolkit/
   echo RHYTHMYX_HOME=$RHYTHMYX_HOME
   echo JAVA_HOME=$JAVA_HOME
   echo ANT_HOME=$ANT_HOME
   $ANT_HOME/bin/ant -f run.xml
   exit 0

