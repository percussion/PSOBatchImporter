package com.percussion.pso.rxws.item.processor;

import com.percussion.pso.importer.IImportItemProcessor;

public interface RxWsItemProcessor extends IImportItemProcessor{

}
