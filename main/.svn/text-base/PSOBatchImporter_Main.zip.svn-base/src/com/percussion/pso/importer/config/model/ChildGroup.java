package com.percussion.pso.importer.config.model;

import java.util.List;

public class ChildGroup {
	private String name;
	private List<Field> childFields;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
