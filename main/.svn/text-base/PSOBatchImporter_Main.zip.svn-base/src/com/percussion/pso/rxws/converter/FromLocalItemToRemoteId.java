package com.percussion.pso.rxws.converter;

import com.percussion.pso.importer.converter.Converter;
import com.percussion.pso.importer.model.ImportItem;
import com.percussion.pso.rxws.item.RxWsContext;

public interface FromLocalItemToRemoteId extends Converter<ImportItem, Integer, Integer, RxWsContext> {

}
