package com.percussion.pso.importer.model;

import javax.xml.bind.annotation.XmlElement;
public class SlotList {
	
	public void Slotlist() {
		
	}
	private ImportSlot[] related;;
	@XmlElement(name="related")
	public ImportSlot[] getRelated() {
		return related;
	}

	public void setRelated(ImportSlot[] related) {
		this.related = related;
	}
}
