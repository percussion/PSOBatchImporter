package com.percussion.pso.importer;

public interface IImportJob 
{
	public void runJob();
	public String getName();
}
