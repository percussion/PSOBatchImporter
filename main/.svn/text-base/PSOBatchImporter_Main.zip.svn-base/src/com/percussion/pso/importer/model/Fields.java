package com.percussion.pso.importer.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public  class Fields {
    @XmlElement(name="field")
    public ImportField[] carray;
}
