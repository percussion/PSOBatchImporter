package com.percussion.pso.importer;

/**
 * TODO Placeholder for now until its merged in.
 * @author adamgent
 *
 */
public interface IImportLog {

}
